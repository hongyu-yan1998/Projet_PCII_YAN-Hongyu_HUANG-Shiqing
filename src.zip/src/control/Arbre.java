package control;

import view.Affichage;
import view.VueDecors;

/**
 * @description：
 * @author: Hongyu YAN and Shiqing HUANG
 * @date: 2021/3/8
 */
public class Arbre extends Decors{

    public Arbre(Affichage affichage, VueDecors vueDecors) {
        super(affichage, vueDecors);
    }
}
