package control;

import view.Affichage;
import view.VueDecors;

/**
 * @description： Des obstacles moblies (animaux, concurrents..)
 * @author: Hongyu YAN and Shiqing HUANG
 * @date: 2021/3/21
 */
public class ObstaclesMobiles extends Decors {
    public ObstaclesMobiles(Affichage affichage, VueDecors vueDecors) {
        super(affichage, vueDecors);
    }
}
